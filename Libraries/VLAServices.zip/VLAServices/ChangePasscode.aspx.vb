Imports VlaServicesBusinessObjects

Partial Class ChangePasscode
    Inherits System.Web.UI.Page

    Private mReturnUrl As String = String.Empty

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Session("CurrentDateTime") = DateTime.Now
        ViewStateUserKey = Session.SessionID
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Len(Request.QueryString("ReturnUrl")) <> 0 Then
                mReturnUrl = CStr(Request.QueryString("ReturnUrl"))
                ViewState("ReturnUrl") = mReturnUrl
            End If

            Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(New Guid(User.Identity.Name))
            If currentUser.UserId = Guid.Empty Then
                FormsAuthentication.SignOut()
                FormsAuthentication.RedirectToLoginPage()
            End If

            If Not VlaSingleUser.IsUserOnePointFiveAuthenticated(currentUser.TokenId) Then
                FormsAuthentication.SignOut()
                FormsAuthentication.RedirectToLoginPage()
            End If

            DirectCast(Master, MasterPage).ShowLoggedInUserID(currentUser)

            LblBlurb.Text = GetLocalResourceObject("Blurb")
            LblCurrent.Text = GetLocalResourceObject("CurrentPasscode") + ":"
            LblNew.Text = GetLocalResourceObject("NewPasscode") + ":"
            LblRepeat.Text = GetLocalResourceObject("RepeatPasscode") + ":"
            BtnUpdate.Text = GetLocalResourceObject("Update")
            BtnCancel.Text = GetLocalResourceObject("Cancel")
            btnContinue.Text = GetLocalResourceObject("Continue")
            LblSuccess.Text = GetLocalResourceObject("Success")

            ValidatorCurrentRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredCurrent"))
            ValidatorNewRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredNew"))
            ValidatorRepeatRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredRepeat"))

            ValidatorCurrentRegExLength.Text = ConstructValidateImage(GetLocalResourceObject("RegExLength"))
            ValidatorNewRegExLength.Text = ConstructValidateImage(GetLocalResourceObject("RegExLength"))
            ValidatorRepeatRegExLength.Text = ConstructValidateImage(GetLocalResourceObject("RegExlength"))

            Dim regExLength As String = "^[a-z0-9A-Z]{6}$"
            ValidatorCurrentRegExLength.ValidationExpression = regExLength
            ValidatorNewRegExLength.ValidationExpression = regExLength
            ValidatorRepeatRegExLength.ValidationExpression = regExLength

            MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(ViewDetails)
        End If
    End Sub

    Protected Sub BtnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnUpdate.Click
        If TxtNew.Text = TxtRepeat.Text Then
            Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(New Guid(User.Identity.Name))

            If VlaSingleUser.ChangePasscode(currentUser.UserId, TxtCurrent.Text, TxtNew.Text) Then
                MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(ViewSuccess)
            Else
                LblError.Text = GetLocalResourceObject("ChangeFailed")
                PnlError.Visible = True
            End If
        Else
            LblError.Text = GetLocalResourceObject("ConfirmedPasscodeFailed")
            PnlError.Visible = True
        End If
    End Sub

    Protected Sub BtnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnCancel.Click        
        NavigateBack()
    End Sub

    Protected Sub BtnContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnContinue.Click
        NavigateBack()
    End Sub

    Private Function ConstructValidateImage(ByVal Description As String) As String
        Return "<img src=""./images/error.jpg"" alt=""" + Description + """ title=""" + Description + """ />" + Description
    End Function
    Protected Sub NavigateBack()
        If mReturnUrl <> String.Empty Then
            Response.Redirect(mReturnUrl, False)
        Else
            Response.Redirect("~/MainMenu.aspx", False)
        End If
    End Sub

End Class
