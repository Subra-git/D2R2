<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ChangeDetails.aspx.vb" Inherits="ChangeDetails" MasterPageFile="~/MasterPage.master"%>
<%@ MasterType VirtualPath="~/MasterPage.master" %>

<asp:Content runat="server" ContentPlaceHolderID="Content" ID="Content">

    <asp:MultiView runat="server" ID="MultiView1">
    
        <asp:View runat="server" ID="ViewDetails">

            <table class="padded">
                <tr>
                    <td><asp:Label runat="server" ID="LblLogin" /></td>
                    <td><asp:TextBox ID="TxtLogin" runat="server" Width="160" MaxLength="50"/><asp:RequiredFieldValidator runat="server" ID="ValidatorLoginRequired" ControlToValidate="TxtLogin" Display="Dynamic" CssClass="validator"/></td>
                </tr>
                <tr>
                    <td><asp:Label runat="server" ID="LblEmail" /></td>
                    <td><asp:TextBox ID="TxtEmail" runat="server" Width="320" oncopy="return false;" onpaste="return false;" oncut="return false;" /><asp:RequiredFieldValidator runat="server" ID="ValidatorEmailRequired" ControlToValidate="TxtEmail" Display="Dynamic" CssClass="validator"/><asp:RegularExpressionValidator runat="server" ID="ValidatorRegExEmail" ControlToValidate="TxtEmail" Display="Dynamic" CssClass="validator"></asp:RegularExpressionValidator></td>
                </tr>
                <tr>
                    <td><asp:Label runat="server" ID="LblEmailRepeat" /></td>
                    <td><asp:TextBox ID="TxtEmailRepeat" runat="server" Width="320" oncopy="return false;" onpaste="return false;" oncut="return false;" /><asp:RequiredFieldValidator runat="server" ID="ValidatorEmailRepeatRequired" ControlToValidate="TxtEmailRepeat" Display="Dynamic" CssClass="validator"/><asp:RegularExpressionValidator runat="server" ID="ValidatorRegExEmailRepeat" ControlToValidate="TxtEmailRepeat" Display="Dynamic" CssClass="validator"></asp:RegularExpressionValidator></td>
                </tr>
                <tr>
                    <td><asp:Label runat="server" ID="LblFirstName"></asp:Label></td>
                    <td><asp:TextBox ID="TxtFirstName" runat="server" Width="160" MaxLength="50"/><asp:RequiredFieldValidator runat="server" ID="ValidatorFirstNameRequired" ControlToValidate="TxtFirstName" Display="Dynamic" CssClass="validator" /></td>
                </tr>
                <tr>
                    <td><asp:Label runat="server" ID="LblLastName"></asp:Label></td>
                    <td><asp:TextBox ID="TxtLastName" runat="server" Width="160" MaxLength="100"/><asp:RequiredFieldValidator runat="server" ID="ValidatorLastNameRequired" ControlToValidate="TxtLastName" Display="Dynamic" CssClass="validator" /></td>
                </tr>
                <tr>
                    <td><asp:Label runat="server" ID="LblOrganisationName"></asp:Label></td>
                    <td><asp:TextBox ID="TxtOrganisationName" runat="server" Width="160" MaxLength="100"/><asp:RequiredFieldValidator runat="server" ID="ValidatorOrganisationNameRequired" ControlToValidate="TxtOrganisationName" Display="Dynamic" CssClass="validator" /></td>
                </tr>
                <tr>
                    <td><asp:Label runat="server" ID="LblPhoneNumber"></asp:Label></td>
                    <td><asp:TextBox ID="TxtPhoneNumber" runat="server" Width="160" MaxLength="50"/><asp:RegularExpressionValidator runat="server" ID="ValidatorRegEx" ControlToValidate="TxtPhoneNumber" Display="Dynamic" CssClass="validator"></asp:RegularExpressionValidator><asp:RequiredFieldValidator runat="server" ID="ValidatorPhoneNumber" ControlToValidate="TxtPhoneNumber" Display="Dynamic" CssClass="validator" /></td>
                </tr>
                <tr>
                    <td>
                        <br /><br />
                    </td>
                    <td>
                        <br /><br />
                    </td>
                </tr>
                <tr>
                    <td>
                        <asp:Label runat="server" ID="LblPassword"></asp:Label>
                    </td>
                    <td>
                        <asp:TextBox runat="server" ID="TxtPassword" Width="160" MaxLength="50" TextMode="Password" /><asp:RequiredFieldValidator runat="server" ID="ValidatorPassword" ControlToValidate="TxtPassword" Display="Dynamic" CssClass="validator" />
                    </td>
                </tr>
            </table>
            
            <asp:Panel runat="server" ID="PnlError" Visible="false" CssClass="error">
                <asp:Image runat="server" ID="ImgError" ImageUrl="~/images/Error.jpg" />
                <asp:Label runat="server" ID="LblError" />
            </asp:Panel>
            
            <asp:Button ID="BtnUpdate" runat="server" CssClass="button" CausesValidation="true" />

            <asp:Button ID="BtnCancel" runat="server" CssClass="button" CausesValidation="false" /><br />
            <br />
            <br />
               
            <asp:Panel runat="server" ID="PnlDisclaimer" Visible="false" cssClass="disclaimer">
                <asp:Literal runat="server" ID="LitDisclaimer" />
            </asp:Panel>

        
        </asp:View>
        
        <asp:View runat="server" ID="ViewSuccess">
        
            <div class="success">
                <asp:Image runat="server" ID="ImgSuccess" ImageUrl="~/images/success.jpg" />            
                <asp:Label runat="server" ID="LblSuccess" />
            </div>

            <asp:Button ID="btnContinue" runat="server" CssClass="button" CausesValidation="false" />

        </asp:View>
    
    </asp:MultiView>

</asp:Content>
