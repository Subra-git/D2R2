Imports VlaServicesBusinessObjects

Partial Class ChangeDetails
    Inherits System.Web.UI.Page

    Private mReturnUrl As String = String.Empty

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Session("CurrentDateTime") = DateTime.Now
        ViewStateUserKey = Session.SessionID
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            If Len(Request.QueryString("ReturnUrl")) <> 0 Then
                mReturnUrl = CStr(Request.QueryString("ReturnUrl"))
                ViewState("ReturnUrl") = mReturnUrl
            End If

            LblLogin.Text = GetLocalResourceObject("Login") + ":"
            LblEmail.Text = GetLocalResourceObject("Email") + ":"
            LblEmailRepeat.Text = GetLocalResourceObject("RepeatEmail") + ":"
            LblFirstName.Text = GetLocalResourceObject("FirstName") + ":"

            LblLastName.Text = GetLocalResourceObject("LastName") + ":"
            LblOrganisationName.Text = GetLocalResourceObject("OrganisationName") + ":"
            LblPhoneNumber.Text = GetLocalResourceObject("PhoneNumber") + ":"

            LblPassword.Text = GetLocalResourceObject("Password") + ":"

            BtnUpdate.Text = GetLocalResourceObject("Update")

            BtnUpdate.Attributes.Add("onClick", "javascript:Page_ClientValidate(); if(Page_IsValid) { var newEmail = document.getElementById('" + TxtEmail.ClientID + "').value; var repeatEmail = document.getElementById('" + TxtEmailRepeat.ClientID + "').value; if(newEmail == repeatEmail) {  return confirm('" + GetLocalResourceObject("UpdateWarning") + "'); } else { alert('" + GetLocalResourceObject("RepeatEmailFailed") + "'); return false; } } else {return  false;}")

            BtnCancel.Text = GetLocalResourceObject("Cancel")
            btnContinue.Text = GetLocalResourceObject("Continue")
            LblSuccess.Text = GetLocalResourceObject("Success")

            ValidatorLoginRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredLogin"))
            ValidatorEmailRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredEmail"))
            ValidatorEmailRepeatRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredEmail"))
            ValidatorFirstNameRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredFirstName"))
            ValidatorLastNameRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredLastName"))
            ValidatorOrganisationNameRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredOrganisationName"))
            ValidatorPhoneNumber.Text = ConstructValidateImage(GetLocalResourceObject("RequiredPhoneNumber"))

            ValidatorRegExEmail.Text = ConstructValidateImage(GetLocalResourceObject("InvalidEmail"))
            ValidatorRegExEmail.ValidationExpression = VLAServicesBusinessObjects.My.Resources.VLAResources.EmailRegEx

            ValidatorRegExEmailRepeat.Text = ConstructValidateImage(GetLocalResourceObject("InvalidEmail"))
            ValidatorRegExEmailRepeat.ValidationExpression = VLAServicesBusinessObjects.My.Resources.VLAResources.EmailRegEx

            ValidatorRegEx.Text = ConstructValidateImage(GetLocalResourceObject("PhoneNumberValidation"))
            ValidatorRegEx.ValidationExpression = "^[ 0-9\+\-\(\)\*\#]*$"

            ValidatorPassword.Text = ConstructValidateImage(GetLocalResourceObject("RequiredPassword"))

            TxtEmail.MaxLength = VLAServicesBusinessObjects.My.Resources.VLAResources.EmailMaxLength
            TxtEmailRepeat.MaxLength = VLAServicesBusinessObjects.My.Resources.VLAResources.EmailMaxLength

            Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(New Guid(User.Identity.Name))
            If currentUser.UserId = Guid.Empty Then
                FormsAuthentication.SignOut()
                FormsAuthentication.RedirectToLoginPage()
            End If

            DirectCast(Master, MasterPage).ShowLoggedInUserID(currentUser)

            If CBool(ConfigurationManager.AppSettings("DisclaimerVisible")) Then
                Dim found As Boolean = False
                For Each currentSystem As VlaSingleSystem In currentUser.VlaSystems
                    If currentSystem.SystemId = New Guid(ConfigurationManager.AppSettings("ProficiencyTestingId")) Then
                        found = True
                        Exit For
                    End If
                Next

                If found Then
                    PnlDisclaimer.Visible = True
                    LitDisclaimer.Text = GetLocalResourceObject("Disclaimer") + " " + "<a href=mailto:" + GetLocalResourceObject("QAEmailAddress") + ">" + GetLocalResourceObject("QAEmailAddress") + "</a>"
                End If
            End If

            TxtLogin.Text = currentUser.Login
            TxtLogin.Enabled = Not currentUser.IsLoginFixed
            TxtEmail.Text = currentUser.Email
            TxtEmailRepeat.Text = currentUser.Email
            TxtFirstName.Text = currentUser.FirstName
            TxtLastName.Text = currentUser.LastName
            TxtOrganisationName.Text = currentUser.OrganisationName
            TxtPhoneNumber.Text = currentUser.PhoneNumber

            MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(ViewDetails)
        End If
    End Sub

    Protected Sub BtnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnUpdate.Click
        Dim oldLogin As String = String.Empty
        Dim newLogin As String = String.Empty

        Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(New Guid(User.Identity.Name))
        oldLogin = currentUser.Login
        newLogin = TxtLogin.Text

        If Not IsPasswordCorrect(oldLogin, TxtPassword.Text) Then
            LblError.Text = GetLocalResourceObject("IncorrectPassword")
            PnlError.Visible = True
            Return
        End If

        If TxtEmail.Text = TxtEmailRepeat.Text Then
            If Not oldLogin.ToLower() = newLogin.ToLower() Then
                Dim partialUser As VlaSinglePartialUser = VlaSinglePartialUser.GetVlaSinglePartialUserByLogin(newLogin)
                If Not partialUser.Login Is Nothing Then
                    ' Login exists, but display a generic error message to discourage use of this
                    ' mechanism to enumerate user IDs.
                    LblError.Text = GetLocalResourceObject("ChangeFailed")
                    PnlError.Visible = True
                Else
                    Save(currentUser)
                End If
            Else
                Save(currentUser)
            End If
        Else
            PnlError.Visible = True
            LblError.Text = GetLocalResourceObject("RepeatEmailFailed")
        End If
    End Sub

    Private Sub Save(ByRef currentUser As VlaSingleUser)
        currentUser.Login = TxtLogin.Text
        currentUser.Email = TxtEmail.Text
        currentUser.FirstName = TxtFirstName.Text
        currentUser.LastName = TxtLastName.Text
        currentUser.OrganisationName = TxtOrganisationName.Text
        currentUser.PhoneNumber = TxtPhoneNumber.Text

        Try
            currentUser.Save()
            MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(ViewSuccess)
        Catch ex As Exception
            LblError.Text = GetLocalResourceObject("ChangeFailed")
            PnlError.Visible = True
        End Try

    End Sub

    Protected Sub BtnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnCancel.Click
        NavigateBack()
    End Sub

    Protected Sub BtnContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnContinue.Click
        NavigateBack()
    End Sub

    Private Function ConstructValidateImage(ByVal Description As String) As String
        Return "<img src=""./images/error.jpg"" alt=""" + Description + """ title=""" + Description + """ />" + Description
    End Function

    Private Function IsPasswordCorrect(ByVal login As String, ByVal password As String) As Boolean
        Return (VlaSingleUser.GetVlaSingleUser(login, password).Login <> String.Empty)
    End Function

    Private Function GetIp() As String
        Dim Context As HttpContext = HttpContext.Current
        Dim sourceIp As String = String.Empty
        sourceIp = Context.Request.ServerVariables("HTTP_X_FORWARDED_FOR")
        If sourceIp = String.Empty Then
            sourceIp = Context.Request.ServerVariables("REMOTE_ADDR")
        End If
        Return sourceIp
    End Function

    Protected Sub NavigateBack()
        If mReturnUrl <> String.Empty Then
            Response.Redirect(mReturnUrl, False)
        Else
            Response.Redirect("~/MainMenu.aspx", False)
        End If
    End Sub

End Class
