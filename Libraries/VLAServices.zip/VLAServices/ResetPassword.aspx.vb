﻿Imports VLAServicesBusinessObjects
Imports System.Web


Partial Class ResetPassword
    Inherits System.Web.UI.Page

    Private mPasswordResetKey As Guid

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Session("CurrentDateTime") = DateTime.Now
        ViewStateUserKey = Session.SessionID
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            MainMultiView.ActiveViewIndex = 0

            InstructionsLabel.Text = GetLocalResourceObject("InstructionsMessage")
            ResetPasswordButton.Text = GetLocalResourceObject("ResetPasswordButtonText")
        End If
    End Sub

    Protected Sub ResetPasswordButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ResetPasswordButton.Click
        Dim resetSuccessful As Boolean = False
        Try
            Dim passwordResetKey As Guid = New Guid(Request.QueryString("key"))
            Dim serv As New ServiceWrapper()
            resetSuccessful = serv.ResetPassword(passwordResetKey)
        Catch ex As Exception
            resetSuccessful = False
        End Try

        If resetSuccessful Then
            ResultsLabel.Text = GetLocalResourceObject("SuccessMessage")
            ReturnButton.Text = GetLocalResourceObject("SuccessButtonText")
        Else
            ResultsLabel.Text = GetLocalResourceObject("FailureMessage")
            ReturnButton.Text = GetLocalResourceObject("FailureButtonText")
        End If

        MainMultiView.ActiveViewIndex = 1
    End Sub

    Protected Sub ReturnButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ReturnButton.Click
        Response.Redirect("Login.aspx")
    End Sub

End Class
