<%@ Page Language="VB" AutoEventWireup="false" CodeFile="Login.aspx.vb" Inherits="Login" MasterPageFile="~/MasterPage.master"  ViewStateEncryptionMode="Always"%>
<%@ MasterType VirtualPath="~/MasterPage.master" %>

<asp:Content runat="server" ContentPlaceHolderID="Content" ID="Content1">
    <asp:MultiView runat="server" ID="MultiView1">
        <asp:View runat="server" ID="TestDatabaseStep">
            <div id="divDatabaseAccessError" runat="server" >
            <asp:Image runat="server" ID="ImgDatabaseAccessError" ImageUrl="~/images/Error.jpg" />
            <asp:Label runat="server" ID="LblDatabaseAccessError" /></div>
        </asp:View>
        <asp:View runat="server" ID="ViewLoginStep1">
            <asp:Label runat="server" ID="LblLoginInstructions" />
            <br />
            <br />
            <table class="padded">
                <tr>
                    <td>
                        <asp:Label ID="LblUsername" runat="server" /></td>
                    <td>
                        <asp:TextBox ID="TxtUsername" runat="server" Width="160" MaxLength="50" 
                            autocomplete="off" />
                        <asp:RequiredFieldValidator
                            runat="server" ID="ValidatorUsernameRequired" ControlToValidate="TxtUsername"
                            Display="Dynamic" CssClass="validator" /></td>
                </tr>
                <tr>
                    <td style="height: 26px">
                        <asp:Label ID="LblPassword" runat="server" /></td>
                    <td style="height: 26px">
                        <asp:TextBox ID="TxtPassword" runat="server" Width="160" TextMode="Password" MaxLength="50" 
                            autocomplete="off" />
                        <asp:RequiredFieldValidator
                            runat="server" ID="ValidatorPasswordRequired" ControlToValidate="TxtPassword"
                            Display="Dynamic" CssClass="validator" /></td>
                </tr>
            </table>
            <asp:Panel runat="server" ID="PnlError" Visible="false" CssClass="error">
                <asp:Image runat="server" ID="ImgError" ImageUrl="~/images/Error.jpg" />
                <asp:Literal runat="server" ID="LitError" />
            </asp:Panel>
            <asp:Button ID="BtnLogin" runat="server" CssClass="button" CausesValidation="true" />
            <div class="horizontalrule">
            </div>
            <br />
            <div id="divPasswordReset" runat="server">
            <asp:Label runat="server" ID="LblPasswordResetInstructions" />
            <br />
            <br />
            <asp:LinkButton ID="BtnResetPassword" runat="server" CausesValidation="false"></asp:LinkButton>
            <br />
            <br />
            <asp:Label ID="lblPasswordReset" runat="server" CssClass="validator" ForeColor="Red" /></div>
        </asp:View>
        <asp:View runat="server" ID="ViewLoginStep2">
            <asp:Label runat="server" ID="LblPreviousLoginStep2" />
            <br />
            <br />
            <asp:Label runat="server" ID="LblLoginInstructionsStep2" />
            <br />
            <br />
            <table class="padded">
                <tr>
                    <td>
                        <asp:Label ID="LblPass1" runat="server"></asp:Label></td>
                    <td>
                        <asp:DropDownList ID="DdlPass1" runat="server">
                        </asp:DropDownList></td>
                </tr>
                <tr>
                    <td>
                        <asp:Label ID="LblPass2" runat="server"></asp:Label></td>
                    <td>
                        <asp:DropDownList ID="DdlPass2" runat="server">
                        </asp:DropDownList></td>
                </tr>
            </table>
            <asp:Panel runat="server" ID="PnlError2" Visible="false" CssClass="error">
                <asp:Image runat="server" ID="ImgError2" ImageUrl="~/images/Error.jpg" />
                <asp:Literal runat="server" ID="LitError2" />
            </asp:Panel>
            <asp:Button ID="BtnLogin2" runat="server" CssClass="button" CausesValidation="true" />
            <asp:Button ID="BtnContinue" runat="server" CssClass="button" CausesValidation="false" />
            <asp:Button ID="BtnContinueBack" runat="server" CssClass="button" visible="false"/>
            <div class="horizontalrule">
            </div>
            <br />
            <div id="divPasscodeReset" runat="server">
            <asp:Label runat="server" ID="LblPasscodeResetInstructions" />
            <br />
            <br />
            <asp:LinkButton ID="BtnResetPasscode" runat="server" CausesValidation="false"></asp:LinkButton>
            <br />
            <br />
            <asp:Label ID="lblPasscodeReset" runat="server" CssClass="validator" ForeColor="Red" /></div>
        </asp:View>
        <asp:View runat="server" ID="ViewLoginSuccess">
            <asp:Label runat="server" ID="lblLoginSuccess" />
            <br />
            <br />
            <asp:Label runat="server" ID="lblPreviousLogin" />
            <br />
            <br />
            <asp:Button ID="BtnLoginSuccessContinue" runat="server" CssClass="button" CausesValidation="false" />
        </asp:View>
    </asp:MultiView>
    <br />
    <asp:Label runat="server" ID="lblLoginMessage" />
    <br />
    <br />
    <asp:Label runat="server" ID="lblFurtherInstructions" />
</asp:Content>
