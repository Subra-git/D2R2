﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="ResetPassword.aspx.vb" Inherits="ResetPassword" %>

<asp:Content ID="Content1" ContentPlaceHolderID="Content" Runat="Server">
    <asp:MultiView runat="server" ID="MainMultiView">
        <asp:View runat="server" ID="PreResetView">
            <asp:Label runat="server" ID="InstructionsLabel" />
            <br />
            <br />
            <asp:Button runat="server" ID="ResetPasswordButton" />
        </asp:View>
        <asp:View runat="server" ID="ResultsView">
            <asp:Label runat="server" ID="ResultsLabel" />
            <br />
            <br />
            <asp:Button runat="server" ID="ReturnButton" />
        </asp:View>
    </asp:MultiView>
</asp:Content>

