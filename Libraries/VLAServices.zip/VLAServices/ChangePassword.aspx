<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ChangePassword.aspx.vb" Inherits="ChangePassword" MasterPageFile="~/MasterPage.master"%>
<%@ MasterType VirtualPath="~/MasterPage.master" %>

<asp:Content runat="server" ContentPlaceHolderID="Content" ID="Content1">

    <asp:MultiView runat="server" ID="MultiView1">
    
        <asp:View runat="server" ID="ViewDetails">
        
            <asp:Label runat="server" ID="LblMustChangePassword" ForeColor="Red" />
        
            <asp:Label runat="server" ID="LblBlurb" />
            
            <br /><br />
            
            <table class="padded">
                <tr>
                    <td><asp:Label runat="server" ID="LblCurrent" /></td>
                    <td>
                        <asp:TextBox runat="server" ID="TxtCurrent" Width="160" MaxLength="20" TextMode="Password" />
                    </td>
                </tr>
                <tr>
                    <td><asp:Label runat="server" ID="LblNew" /></td>
                    <td>
                        <asp:TextBox runat="server" ID="TxtNew" Width="160" MaxLength="20" TextMode="Password" />
                    </td>
                    <td>
                        <div><asp:RequiredFieldValidator runat="server" ID="ValidatorNewRequired" ControlToValidate="TxtNew" Display="Dynamic" CssClass="validator" /></div>
                        <div><asp:RegularExpressionValidator runat="server" ID="ValidatorNewRegExLength" ControlToValidate="TxtNew" Display="Dynamic" CssClass="validator" /></div>
                        <div><asp:RegularExpressionValidator runat="server" ID="ValidatorNewRegExNumbers" ControlToValidate="TxtNew" Display="Dynamic" CssClass="validator" /></div>
                        <div><asp:RegularExpressionValidator runat="server" ID="ValidatorNewRegExLetters" ControlToValidate="TxtNew" Display="Dynamic" CssClass="validator" /></div>
                        <div><asp:CustomValidator runat="server" ID="ValidatorNewContainsPassword" ControlToValidate="TxtNew" Display="Dynamic" CssClass="validator" /></div>
                    </td>
                </tr>
                <tr>
                    <td><asp:Label runat="server" ID="LblRepeat" /></td>
                    <td>
                        <asp:TextBox runat="server" ID="TxtRepeat" Width="160" MaxLength="20" TextMode="Password"/>
                    </td>
                    <td>
                        <div><asp:RequiredFieldValidator runat="server" ID="ValidatorRepeatRequired" ControlToValidate="TxtRepeat" Display="Dynamic" CssClass="validator" /></div>
                        <div><asp:RegularExpressionValidator runat="server" ID="ValidatorRepeatRegExLength" ControlToValidate="TxtRepeat" Display="Dynamic" CssClass="validator" /></div>
                        <div><asp:RegularExpressionValidator runat="server" ID="ValidatorRepeatRegExNumbers" ControlToValidate="TxtRepeat" Display="Dynamic" CssClass="validator" /></div>
                        <div><asp:RegularExpressionValidator runat="server" ID="ValidatorRepeatRegExLetters" ControlToValidate="TxtRepeat" Display="Dynamic" CssClass="validator" /></div>
                        <div><asp:CustomValidator runat="server" ID="ValidatorRepeatContainsPassword" ControlToValidate="TxtNew" Display="Dynamic" CssClass="validator" /></div>
                    </td>
                </tr>
            </table>

            <asp:Panel runat="server" ID="PnlError" Visible="false" CssClass="error">
                <asp:Image runat="server" ID="ImgError" ImageUrl="~/images/Error.jpg" />
                <asp:Label runat="server" ID="LblError" />
            </asp:Panel>

            <asp:Button ID="BtnUpdate" runat="server" CssClass="button" CausesValidation="true" />

            <asp:Button ID="BtnCancel" runat="server" CssClass="button" CausesValidation="false" />
        
        </asp:View>
        
        <asp:View runat="server" ID="ViewSuccess">
            
            <div class="success">
                <asp:Image runat="server" ID="ImgSuccess" ImageUrl="~/images/success.jpg" />            
                <asp:Label runat="server" ID="LblSuccess" />
            </div>

            <asp:Button ID="btnContinue" runat="server" CssClass="button" CausesValidation="false" />
        
        </asp:View>
    
    </asp:MultiView>



</asp:Content>
