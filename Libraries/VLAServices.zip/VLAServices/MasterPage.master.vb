Imports System.Resources
Imports VlaServicesBusinessObjects

Partial Class MasterPage
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
        
            Dim node As SiteMapNode = SiteMap.CurrentNode

            'Set the page title
            LblTitle.Text = GetGlobalResourceObject("Pages", node.Title)

        End If
    End Sub

    Public Sub ShowLoggedInUserID(ByVal user As VlaSingleUser)
        Dim LblName As Label = DirectCast(FindControl("LblName"), Label)
        LblName.Text = GetGlobalResourceObject("CommonText", "LoggedInAs") + " " + Server.HtmlEncode(user.Login)
    End Sub

End Class

