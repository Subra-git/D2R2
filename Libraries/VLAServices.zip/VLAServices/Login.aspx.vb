Imports VLAServicesBusinessObjects
Imports System.Web

Partial Class Login
    Inherits System.Web.UI.Page

    Private mTokenId As Guid = Guid.Empty

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Session("CurrentDateTime") = DateTime.Now
        ViewStateUserKey = Session.SessionID
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblPasswordReset.Visible = False
        lblPasscodeReset.Visible = False

        If Not Page.IsPostBack Then
            Dim success As Boolean = False
            MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(TestDatabaseStep)
            ' this call counts the number of users in the user table
            ' so providing there is at least one user - success should be true

            Try
                success = TestDatabase.TestDatabaseAccess()  'test database access
            Catch ex As Exception
                success = False
            End Try

            If Not success Then
                divDatabaseAccessError.Visible = True
                LblDatabaseAccessError.Text = GetLocalResourceObject("DatabaseAccessError")
            Else
                MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(ViewLoginStep1)

                LblUsername.Text = GetLocalResourceObject("Username") + ":"
                LblPassword.Text = GetLocalResourceObject("Password") + ":"
                BtnLogin.Text = GetLocalResourceObject("Login")
                ValidatorUsernameRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredUsername"))
                ValidatorPasswordRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredPassword"))

                BtnResetPassword.Text = GetLocalResourceObject("ResetPassword")
                lblPasswordReset.Text = GetLocalResourceObject("PasswordReset")
                LblLoginInstructions.Text = GetLocalResourceObject("LoginInstructions")
                LblPasswordResetInstructions.Text = GetLocalResourceObject("PasswordResetInstructions")

                BtnLogin2.Text = GetLocalResourceObject("Login")
                BtnContinue.Text = GetLocalResourceObject("Skip")
                BtnContinueBack.Text = GetLocalResourceObject("Continue")
                BtnResetPasscode.Text = GetLocalResourceObject("ResetPasscode")
                lblPasscodeReset.Text = GetLocalResourceObject("PasscodeReset")

                lblLoginSuccess.Text = GetLocalResourceObject("LoginSuccess")
                BtnLoginSuccessContinue.Text = GetLocalResourceObject("Continue")

                LblLoginInstructionsStep2.Text = GetLocalResourceObject("LoginInstructionsStep2")
                LblPasscodeResetInstructions.Text = GetLocalResourceObject("PasscodeResetInstructions")

                Dim messageObject As LoginMessage = LoginMessage.GetLoginMessage()
                If messageObject Is Nothing Then
                    lblLoginMessage.Text = String.Empty
                Else
                    lblLoginMessage.Text = messageObject.Text
                End If

                lblFurtherInstructions.Text = GetLocalResourceObject("FurtherInstructions")

                DdlPass1.DataSource = GetDropDownDataSource()
                DdlPass2.DataSource = GetDropDownDataSource()

                DdlPass1.DataBind()
                DdlPass2.DataBind()
                ViewState("TokenId") = Guid.Empty.ToString()
                End If

        Else
                mTokenId = New Guid(ViewState("TokenId").ToString())
        End If

    End Sub

    Private Function GetDropDownDataSource() As Char()
        Dim allPasscodeChars As String = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789"
        Dim charArray As Char()

        charArray = allPasscodeChars.ToCharArray()
        Return charArray
    End Function
    Protected Sub BtnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnLogin.Click
        Dim sourceIp As String = GetIp()

        Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(TxtUsername.Text, TxtPassword.Text, sourceIp)
        Dim returnUrl As String = String.Empty

        If currentUser.UserId <> Guid.Empty Then
            If currentUser.IsAllocatedOnePointFiveSystems Then
                If Not Len(Request.QueryString("ReturnUrl")) = 0 Then
                    returnUrl = Request.QueryString("ReturnUrl")
                    BtnContinue.Visible = Not currentUser.VlaSystems.IsOnePointFiveRequired(returnUrl)
                End If
                LblPass1.Text = GetLocalResourceObject("PasscodeCharacter") + " " + currentUser.PasscodeIndex1.ToString() + ":"
                LblPass2.Text = GetLocalResourceObject("PasscodeCharacter") + " " + currentUser.PasscodeIndex2.ToString() + ":"
                ViewState("TokenId") = currentUser.TokenId.ToString()
                Dim LblName As Label = DirectCast(Master.FindControl("LblName"), Label)
                LblName.Text = GetGlobalResourceObject("CommonText", "LoggedInAs") + " " + currentUser.Login.ToString()
                LblPreviousLoginStep2.Text = GetLocalResourceObject("PreviousLogin") & " "
                If currentUser.PreviousLoginDate <> Nothing Then
                    LblPreviousLoginStep2.Text &= GetFormattedDateString(currentUser.PreviousLoginDate)
                Else
                    LblPreviousLoginStep2.Text &= "Never"
                End If
                MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(ViewLoginStep2)
            Else
                ViewState("TokenId") = currentUser.TokenId.ToString()
                lblPreviousLogin.Text = GetLocalResourceObject("PreviousLogin") & " "
                If currentUser.PreviousLoginDate <> Nothing Then
                    lblPreviousLogin.Text &= GetFormattedDateString(currentUser.PreviousLoginDate)
                Else
                    LblPreviousLogin.Text &= "Never"
                End If
                MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(ViewLoginSuccess)
            End If
            FormsAuthentication.SetAuthCookie(currentUser.TokenId.ToString(), False)
        Else
            Dim currentPartialUser As VlaSinglePartialUser = VlaSinglePartialUser.GetVlaSinglePartialUserByLogin(TxtUsername.Text)
            LitError.Text = GetLocalResourceObject("LoginFailedPart1") + " " + Settings.GetMaxLoginAttempts.ToString + " " + GetLocalResourceObject("LoginFailedPart2")
            If currentPartialUser.UserId <> Guid.Empty Then
                If currentPartialUser.IsLockedOut Then
                    LitError.Text = "<a href=mailto:" + GetLocalResourceObject("ITUHelpDeskEmail") + ">" + GetLocalResourceObject("AccountLockedOut") + "</a>"
                    divPasswordReset.Visible = False
                End If
            End If
            PnlError.Visible = True
        End If
    End Sub
    Protected Sub BtnLogin2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnLogin2.Click
        Dim sourceIp As String = GetIp()

        Dim currentUser As VlaSingleUser = Nothing
        Dim fail As Boolean = False

        Try
            currentUser = VlaSingleUser.GetVlaSingleUser(mTokenId, System.Convert.ToChar(DdlPass1.SelectedValue), System.Convert.ToChar(DdlPass2.SelectedValue), sourceIp)
        Catch ex As Exception
            fail = True
        End Try

        If Not fail Then
            If currentUser.MustChangePassword Then
                If Request.QueryString("ReturnUrl") IsNot Nothing Then
                    Response.Redirect("ChangePassword.aspx?ReturnUrl=" & HttpUtility.UrlEncode(Request.QueryString("ReturnUrl")))
                Else
                    Response.Redirect("ChangePassword.aspx")
                End If
            Else
                FormsAuthentication.RedirectFromLoginPage(currentUser.TokenId.ToString(), False)
            End If
        Else
            Dim currentPartialUser As VlaSinglePartialUser = VlaSinglePartialUser.GetVlaSinglePartialUserByLogin(TxtUsername.Text)
            LitError2.Text = GetLocalResourceObject("LoginFailedPart1") + " " + Settings.GetMaxLoginAttempts.ToString + " " + GetLocalResourceObject("LoginFailedPart2")
            If currentPartialUser.UserId <> Guid.Empty Then
                If currentPartialUser.IsLockedOut Then
                    LitError2.Text = "<a href=mailto:" + GetLocalResourceObject("ITUHelpDeskEmail") + ">" + GetLocalResourceObject("AccountLockedOut") + "</a>"
                    PnlError2.Visible = True
                    FormsAuthentication.SignOut()  ' force log out. this destroys the authentication cookie
                    BtnContinue.Visible = False
                    BtnLogin2.Visible = False
                    divPasscodeReset.Visible = False
                    BtnContinueBack.Visible = True
                End If
            End If
            PnlError2.Visible = True
        End If
    End Sub
    Protected Sub BtnLoginSuccessContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnLoginSuccessContinue.Click
        Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(New Guid(DirectCast(ViewState("TokenId"), String)))
        If currentUser.MustChangePassword Then
            If Request.QueryString("ReturnUrl") IsNot Nothing Then
                Response.Redirect("ChangePassword.aspx?ReturnUrl=" & HttpUtility.UrlEncode(Request.QueryString("ReturnUrl")))
            Else
                Response.Redirect("ChangePassword.aspx")
            End If
        Else
            If Request.QueryString("IgnoreReturnUrl") = "True" Then
                Response.Redirect("MainMenu.aspx")
            End If
            FormsAuthentication.RedirectFromLoginPage(currentUser.TokenId.ToString(), False)
        End If
    End Sub
    Protected Sub BtnContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnContinue.Click
        Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(mTokenId)

        If currentUser.UserId <> Guid.Empty Then
            FormsAuthentication.RedirectFromLoginPage(currentUser.TokenId.ToString(), False)
        End If
    End Sub
    Protected Sub BtnContinueBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnContinueBack.Click
        FormsAuthentication.RedirectToLoginPage()
    End Sub
    Private Function ConstructValidateImage(ByVal Description As String) As String
        Return "<img src=""./images/error.jpg"" alt=""" + Description + """ title=""" + Description + """ />" + Description
    End Function
    Protected Sub BtnResetPassword_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnResetPassword.Click
        ValidatorUsernameRequired.Validate()
        If ValidatorUsernameRequired.IsValid Then
            VlaSingleUser.RequestPasswordReset(TxtUsername.Text)
            ' Always display the same result message, regardless of whether the reset
            ' succeeded or failed, to prevent user enumeration.
            lblPasswordReset.Visible = True
        End If
    End Sub
    Protected Sub BtnResetPasscode_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnResetPasscode.Click
        If mTokenId <> Guid.Empty Then
            Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(mTokenId)
            If currentUser.UserId <> Guid.Empty Then
                If currentUser.IsAllocatedOnePointFiveSystems Then
                    If VlaSingleUser.ResetPasscode(currentUser.Login) Then
                        lblPasscodeReset.Visible = True
                        Dim updatedCurrentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(mTokenId)
                        LblPass1.Text = GetLocalResourceObject("PasscodeCharacter") + " " + updatedCurrentUser.PasscodeIndex1.ToString() + ":"
                        LblPass2.Text = GetLocalResourceObject("PasscodeCharacter") + " " + updatedCurrentUser.PasscodeIndex2.ToString() + ":"
                    End If
                End If
            End If
        End If
    End Sub
    Private Function GetIp() As String
        Dim Context As HttpContext = HttpContext.Current
        Dim sourceIp As String = String.Empty
        sourceIp = Context.Request.ServerVariables("HTTP_X_FORWARDED_FOR")
        If sourceIp = String.Empty Then
            sourceIp = Context.Request.ServerVariables("REMOTE_ADDR")
        End If
        Return sourceIp
    End Function

    Private Function GetFormattedDateString(ByVal dateToFormat As DateTime) As String
        Dim s As String
        s = dateToFormat.ToString("dd/MM/yyyy h:mm:ss tt ")
        If TimeZone.CurrentTimeZone.IsDaylightSavingTime(dateToFormat) Then
            s += "BST"
        Else
            s += "GMT"
        End If
        Return s
    End Function
End Class

