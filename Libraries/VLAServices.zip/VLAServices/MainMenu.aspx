<%@ Page Language="VB" AutoEventWireup="false" CodeFile="MainMenu.aspx.vb" Inherits="MainMenu" MasterPageFile="~/MasterPage.master"%>
<%@ MasterType VirtualPath="~/MasterPage.master" %>

<asp:Content runat="server" ContentPlaceHolderID="Content" ID="Content1">

    <asp:Label runat="server" ID="LblHelpBlurb"  /><br />
    <br />
    <div class="horizontalrule"></div>
    
    <asp:GridView runat="server" ID="GridViewApplications" AutoGenerateColumns="false" ShowHeader="false" GridLines="None">
        <Columns>

            <asp:TemplateField>
                <ItemTemplate>
                    <asp:HyperLink runat="server" ID="LnkAppImage" NavigateUrl='<%#Eval("Url") %>'>
                        <asp:Image runat="server" ID="ImgApp" />
                    </asp:HyperLink>
                </ItemTemplate>
            </asp:TemplateField>

            <asp:TemplateField>
                <ItemTemplate>
                    <h3><asp:HyperLink runat="server" ID="LnkAppTitle" NavigateUrl='<%#Eval("Url") %>'/></h3>
                    <asp:Label runat="server" ID="LblAppBlurb" />
                </ItemTemplate>
            </asp:TemplateField>
            
        </Columns>
    </asp:GridView>

    <div class="horizontalrule"></div>
    
    <table class="padded">
        <tr>
            <td><asp:HyperLink ID="changePasswordLink" NavigateUrl="~/ChangePassword.aspx" runat="server" /></td>
        </tr>
        <tr>
            <td><asp:HyperLink ID="changePasscodeLink" NavigateUrl="~/ChangePasscode.aspx" runat="server" /></td>
        </tr>
        <tr>
            <td><asp:HyperLink ID="changeDetailsLink" NavigateUrl="~/ChangeDetails.aspx" runat="server" /></td>
        </tr>        
    </table>
    
    <asp:Button ID="logoutButton" runat="server" Text="Button" CssClass="button"/>
    
</asp:Content>
