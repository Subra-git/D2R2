Imports VlaServicesBusinessObjects

Partial Class DatabaseAccessTest
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        ViewStateUserKey = Session.SessionID
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim success As Boolean = False

            Try
                success = TestDatabase.TestDatabaseAccess()
            Catch ex As Exception
                success = False
            End Try

            If success Then
                Response.Write("Database Access Working")
            Else
                Response.Write("Database Access Not Working")
            End If
        End If
    End Sub

    Private Function ConstructValidateImage(ByVal Description As String) As String
        Return "<img src=""./images/error.jpg"" alt=""" + Description + """ title=""" + Description + """ />" + Description
    End Function

End Class
