Imports VLAServicesBusinessObjects
Imports System.Text.RegularExpressions

Partial Class ChangePassword
    Inherits System.Web.UI.Page

    Private mReturnUrl As String = String.Empty

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Session("CurrentDateTime") = DateTime.Now
        ViewStateUserKey = Session.SessionID
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Len(Request.QueryString("ReturnUrl")) <> 0 Then
                mReturnUrl = CStr(Request.QueryString("ReturnUrl"))
                ViewState("ReturnUrl") = mReturnUrl
            End If

            Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(New Guid(User.Identity.Name))
            If currentUser.UserId = Guid.Empty Then
                FormsAuthentication.SignOut()
                FormsAuthentication.RedirectToLoginPage()
            End If

            If currentUser.MustChangePassword Then
                LblMustChangePassword.Visible = True
            Else
                LblMustChangePassword.Visible = False
            End If

            DirectCast(Master, MasterPage).ShowLoggedInUserID(currentUser)

            SetLabelText()
            LoadValidators()

            MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(ViewDetails)
        End If
    End Sub

    Private Sub SetLabelText()
        LblMustChangePassword.Text = GetLocalResourceObject("MustChangePassword")
        LblBlurb.Text = GetLocalResourceObject("Blurb")
        LblCurrent.Text = GetLocalResourceObject("CurrentPassword") + ":"
        LblNew.Text = GetLocalResourceObject("NewPassword") + ":"
        LblRepeat.Text = GetLocalResourceObject("RepeatPassword") + ":"
        BtnUpdate.Text = GetLocalResourceObject("Update")
        BtnCancel.Text = GetLocalResourceObject("Cancel")
        btnContinue.Text = GetLocalResourceObject("Continue")
        LblSuccess.Text = GetLocalResourceObject("Success")
    End Sub

    Private Sub LoadValidators()
        ValidatorNewRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredNew"))
        ValidatorRepeatRequired.Text = ConstructValidateImage(GetLocalResourceObject("RequiredRepeat"))

        ValidatorNewRegExLength.Text = ConstructValidateImage(GetLocalResourceObject("RegExLength"))
        ValidatorRepeatRegExLength.Text = ConstructValidateImage(GetLocalResourceObject("RegExlength"))

        ValidatorNewRegExNumbers.Text = ConstructValidateImage(GetLocalResourceObject("RegExNumbers"))
        ValidatorRepeatRegExNumbers.Text = ConstructValidateImage(GetLocalResourceObject("RegExNumbers"))

        ValidatorNewRegExLetters.Text = ConstructValidateImage(GetLocalResourceObject("RegExLetters"))
        ValidatorRepeatRegExLetters.Text = ConstructValidateImage(GetLocalResourceObject("RegExLetters"))

        ValidatorNewContainsPassword.Text = ConstructValidateImage(GetLocalResourceObject("PasswordContainsPassword"))
        ValidatorRepeatContainsPassword.Text = ConstructValidateImage(GetLocalResourceObject("PasswordContainsPassword"))

        Dim regExLetters As String = "^.*[a-zA-Z].*$"
        ValidatorNewRegExLetters.ValidationExpression = regExLetters
        ValidatorRepeatRegExLetters.ValidationExpression = regExLetters

        Dim regExLength As String = "^[\s\S]{8,20}$"
        ValidatorNewRegExLength.ValidationExpression = regExLength
        ValidatorRepeatRegExLength.ValidationExpression = regExLength

        Dim regExNumbers As String = "^.*[0-9].*$"
        ValidatorNewRegExNumbers.ValidationExpression = regExNumbers
        ValidatorRepeatRegExNumbers.ValidationExpression = regExNumbers
    End Sub

    Private Sub DisableValidators()
        ValidatorNewRegExLetters.EnableClientScript = False
        ValidatorRepeatRegExLetters.EnableClientScript = False

        ValidatorNewRegExNumbers.EnableClientScript = False
        ValidatorRepeatRegExNumbers.EnableClientScript = False
    End Sub

    Protected Sub BtnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnUpdate.Click
        If Page.IsValid Then
            If TxtNew.Text = TxtRepeat.Text Then
                Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(New Guid(User.Identity.Name))

                If VlaSingleUser.ChangePassword(currentUser.UserId, TxtCurrent.Text, TxtNew.Text) Then
                    MultiView1.ActiveViewIndex = MultiView1.Views.IndexOf(ViewSuccess)
                Else
                    LblError.Text = GetLocalResourceObject("ChangeFailed")
                    PnlError.Visible = True
                End If
            Else
                PnlError.Visible = True
                LblError.Text = GetLocalResourceObject("ConfirmedPasswordFailed")
            End If
        End If
    End Sub

    Protected Sub BtnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnCancel.Click        
        NavigateBack()
    End Sub

    Protected Sub BtnContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnContinue.Click
        NavigateBack()
    End Sub

    Protected Sub ValidatorNewContainsPassword_ServerValidate(ByVal sender As Object, ByVal e As ServerValidateEventArgs) Handles ValidatorNewContainsPassword.ServerValidate
        e.IsValid = Not ContainsPassword(TxtNew.Text)
    End Sub

    Protected Sub ValidatorRepeatContainsPassword_ServerValidate(ByVal sender As Object, ByVal e As ServerValidateEventArgs) Handles ValidatorRepeatContainsPassword.ServerValidate
        e.IsValid = Not ContainsPassword(TxtRepeat.Text)
    End Sub

    Private Function ConstructValidateImage(ByVal Description As String) As String
        Return "<img src=""./images/error.jpg"" alt=""" + Description + """ title=""" + Description + """ />" + Description
    End Function
    Protected Sub NavigateBack()
        If ViewState("ReturnUrl") IsNot Nothing Then
            Response.Redirect(ViewState("ReturnUrl"), False)
        Else
            Response.Redirect("~/MainMenu.aspx", False)
        End If
    End Sub

    ''' <summary>
    ''' Returns true if the given string does NOT contain the string "password" or 
    ''' any case variation (such as "Password" or "PASSWORD").
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Function ContainsPassword(ByVal stringToTest As String) As Boolean
        Dim regexObject As Regex = New Regex("password", RegexOptions.IgnoreCase)
        Return regexObject.IsMatch(stringToTest)
    End Function
End Class
