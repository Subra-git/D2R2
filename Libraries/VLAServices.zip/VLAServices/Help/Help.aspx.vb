Imports VlaServicesBusinessObjects

Partial Class Help
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            'Help page


        End If
    End Sub

    Private Function ConstructValidateImage(ByVal Description As String) As String
        Return "<img src=""./images/error.jpg"" alt=""" + Description + """ title=""" + Description + """ />" + Description
    End Function

End Class
