<%@ Page Language="VB" AutoEventWireup="false" CodeFile="Help.aspx.vb" Inherits="Help" %>


<html xmlns="http://www.w3.org/1999/xhtml" >
    <head id="Head1" runat="server">
        <title>APHA Admin Help</title>
        <link href="<%= VirtualPathUtility.ToAbsolute("~/style/Help.css") %>" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <form id="form1" runat="server">
            <div class="divArea">Single Sign-On Help</div>
            <div class="divPageTitle">General</div>
                <div class="divPageBody">
                    <div class="divParagraph">This is the single sign-on website for the Animal & Plant Health Agency. From here you can gain access to APHA business applications available over the internet.</div>
                    <div class="divParagraph">The single sign-on website has two authentication levels. The basic level of authentication requires a username and password. The username is not case sensitive whereas the password is case sensitive. Strong passwords contain a collection of numbers, special characters and both upper and lower case letters. You have 5 attempts to get the username / password combination correct. On the 5th incorrect attempt your account shall become locked out. If you suspect that your account is locked out please contact the APHA ITU help desk.</div>
                    <div class="divParagraph">The second authentication process requires further information from the user. Two characters from a passcode must be correctly selected from drop down lists. Passcodes are case sensitive. This feature is designed as a measure against key logging software to maliciously obtain user credentials. </div>
                    <div class="divParagraph">All passwords and passcodes are emailed to users. If you have lost your password but know your username, the password can be reset. This is done by entering the username into the username field on the login page and then pressing the reset password link, located below the login button. You will then received a new, randomly generated password, by email. Similarly, if you have lost your passcode you can reset your passcode once you have successfully entered a correct username and password.</div>
                    <div class="divParagraph">Once authentication is complete you will be re-directed to the application or presented with the main menu that provides a list of applications to chose from. From here you can follow links to any application you have access to navigate to web pages that allow you to change your details and change your password and passcode. </div>
                    <div class="divParagraph">When changing a password, for security reasons, you must correctly enter your old password before entering a new password. The new password must contain at least  one number and at least one letter. It must also be a minimum of 8 characters in length. The use of special characters to make the password more difficult to guess/crack is strongly recommended. Passcodes can contain lower or upper case letters and/or the digits 1 � 9. </div>
                    <div class="divParagraph">To exit the application you should press the logout button.  This helps maintain the security of the system. Pressing the logout button takes you back to the login page. </div>
                </div>
        </form>
    </body>
</html>