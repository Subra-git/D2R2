Imports VlaServicesBusinessObjects

Partial Class MainMenu
    Inherits System.Web.UI.Page

    Private mIsOnePointFiveAuthenticated As Boolean = False

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Session("CurrentDateTime") = DateTime.Now
        ViewStateUserKey = Session.SessionID
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            LblHelpBlurb.Text = GetLocalResourceObject("HelpBlurb")
            logoutButton.Text = GetLocalResourceObject("Logout")
            changePasswordLink.Text = GetLocalResourceObject("ChangePassword")
            changeDetailsLink.Text = GetLocalResourceObject("ChangeDetails")
            changePasscodeLink.Text = GetLocalResourceObject("ChangePasscode")

            Dim currentUser As VlaSingleUser = VlaSingleUser.GetVlaSingleUser(New Guid(User.Identity.Name))
            If currentUser.UserId = Guid.Empty Then
                FormsAuthentication.SignOut()
                FormsAuthentication.RedirectToLoginPage()
            End If

            DirectCast(Master, MasterPage).ShowLoggedInUserID(currentUser)

            mIsOnePointFiveAuthenticated = VlaSingleUser.IsUserOnePointFiveAuthenticated(New Guid(User.Identity.Name))
            ViewState("IsOnePointFiveAuthenticated") = mIsOnePointFiveAuthenticated
            changePasscodeLink.Visible = mIsOnePointFiveAuthenticated

            GridViewApplications.DataSource = currentUser.VlaSystems
            GridViewApplications.DataBind()
        Else
            mIsOnePointFiveAuthenticated = CBool(ViewState("IsOnePointFiveAuthenticated"))
        End If

    End Sub

    Protected Sub GridViewApplications_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles GridViewApplications.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lnkAppImage As HyperLink = e.Row.FindControl("LnkAppImage")
            Dim lnkAppTitle As HyperLink = e.Row.FindControl("LnkAppTitle")
            Dim imgApp As Image = e.Row.FindControl("ImgApp")
            Dim lblAppBlurb As Label = e.Row.FindControl("LblAppBlurb")
           
            Dim appTitle As String = GetLocalResourceObject("App_" + DataBinder.Eval(e.Row.DataItem, "Name").ToString.Replace(" ", "") + "_Title")
            If Not String.IsNullOrEmpty(appTitle) Then
                lnkAppTitle.Text = appTitle
            Else
                lnkAppTitle.Text = DataBinder.Eval(e.Row.DataItem, "Name")
            End If

            Dim appBlurb As String = GetLocalResourceObject("App_" + DataBinder.Eval(e.Row.DataItem, "Name").ToString.Replace(" ", "") + "_Blurb")
            If Not String.IsNullOrEmpty(appBlurb) Then
                lblAppBlurb.Text = appBlurb
            Else
                lblAppBlurb.Text = DataBinder.Eval(e.Row.DataItem, "Description")
            End If

            Dim appImageUrl As String = GetLocalResourceObject("App_" + DataBinder.Eval(e.Row.DataItem, "Name").ToString.Replace(" ", "") + "_ImageUrl")
            If Not String.IsNullOrEmpty(appImageUrl) Then
                imgApp.ImageUrl = appImageUrl
            Else
                imgApp.ImageUrl = "~/images/genericApplicationImage.png"
            End If

            If Not mIsOnePointFiveAuthenticated Then
                Dim requiresOnePointFive As Boolean = DataBinder.Eval(e.Row.DataItem, "RequiresOnePointFive")
                If requiresOnePointFive Then
                    lnkAppImage.Enabled = False
                    lnkAppTitle.Enabled = False
                    lnkAppTitle.CssClass = "appLink2"     'this is not working in safari / firefox
                    e.Row.CssClass = "appLink2"
                Else
                    lnkAppTitle.CssClass = "appLink"
                    e.Row.CssClass = "appLink"
                End If
            Else
                lnkAppTitle.CssClass = "appLink"
                e.Row.CssClass = "appLink"
            End If

           
        End If
    End Sub

    Protected Sub logoutButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles logoutButton.Click
        VlaSingleUser.Logout(New Guid(Context.User.Identity.Name))
        FormsAuthentication.SignOut()
        FormsAuthentication.RedirectToLoginPage()
    End Sub

    
End Class
