Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports UserManagementBusinessObjects
Imports System.Diagnostics

<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class Service
    Inherits System.Web.Services.WebService

    Public Structure VlaUser
        Public Id As Guid
        Public TokenId As Guid
        Public Login As String
        Public Email As String
        Public FirstName As String
        Public LastName As String
        Public OrganisationName As String
        Public PhoneNumber As String
        Public PasscodeIndex1 As Integer
        Public PasscodeIndex2 As Integer
        Public IsAllocatedOnePointFiveSystems As Boolean
        Public IsLoginFixed As Boolean
        Public MustChangePassword As Boolean
        Public PreviousLoginDate As DateTime
        Public PasswordResetKey As Guid
        Public PasswordResetKeyDate As DateTime
        Public Systems() As VlaSystem
    End Structure

    Public Structure VlaPartialUser
        Public Id As Guid
        Public Login As String
        Public Email As String
        Public IsLockedOut As Boolean
    End Structure

    Public Structure VlaSystem
        Public Id As Guid
        Public Name As String
        Public Url As String
        Public Description As String
        Public Roles() As VlaRole
        Public RequiresOnePointFive As Boolean
    End Structure

    Public Structure VlaRole
        Public Id As Guid
        Public Name As String
    End Structure

    <WebMethod()> _
    Public Function GetUser(ByVal login As String, ByVal password As String) As VlaUser
        Try
            Dim userObject As VlaSingleUser

            userObject = VlaSingleUser.GetVlaSingleUser(login, password)

            Return ConvertToStructure(userObject)
        Catch ex As Exception
            If TypeOf (ex.InnerException.InnerException) Is UserManagementBusinessObjects.AuthenticationFailedException Then
                Return Nothing
            Else
                WriteLogEntry(ex)
                Return Nothing
            End If
        End Try
    End Function

    <WebMethod()> _
    Public Function GetUserWithIp(ByVal login As String, ByVal password As String, ByVal sourceIp As String) As VlaUser
        Try
            Dim userObject As VlaSingleUser

            userObject = VlaSingleUser.GetVlaSingleUser(login, password, sourceIp)

            Return ConvertToStructure(userObject)
        Catch ex As Exception
            If TypeOf (ex.InnerException.InnerException) Is UserManagementBusinessObjects.AuthenticationFailedException Then
                Return Nothing
            Else
                WriteLogEntry(ex)
                Return Nothing
            End If
        End Try
    End Function

    <WebMethod()> _
    Public Function GetUserByLoginPass(ByVal login As String, ByVal password As String) As VlaUser
        Try
            Dim userObject As VlaSingleUser
            userObject = VlaSingleUser.GetVlaSingleUserToValidatePassword(login, password)
            Return ConvertToStructure(userObject)
        Catch ex As Exception
            If TypeOf (ex.InnerException.InnerException) Is UserManagementBusinessObjects.AuthenticationFailedException Then
                Return Nothing
            Else
                WriteLogEntry(ex)
                Return Nothing
            End If
        End Try
    End Function

    <WebMethod()> _
       Public Function FindUsersByEmail(ByVal email As String) As VlaPartialUser()
        Try
            Dim findCollection As VlaPartialUserCollection

            findCollection = VlaPartialUserCollection.GetVlaPartialUserCollectionForEmail(email)

            Return ConvertToStructure(findCollection)
        Catch ex As Exception
            WriteLogEntry(ex)
            Return Nothing
        End Try
    End Function

    <WebMethod()> _
    Public Function FindUserByLogin(ByVal login As String) As VlaPartialUser
        ' N.B. Logins are unique so this method will only return one item.
        Try
            Dim userObject As VlaSinglePartialUser

            userObject = VlaSinglePartialUser.GetVlaSinglePartialUserByLogin(login)

            Return ConvertToStructure(userObject)

        Catch ex As Exception
            WriteLogEntry(ex)
            Return Nothing
        End Try
    End Function

    <WebMethod()> _
       Public Function FindUserByUserId(ByVal userId As Guid) As VlaPartialUser
        ' N.B. Ids are unique so this method will only return one item.
        Try
            Dim userObject As VlaSinglePartialUser

            userObject = VlaSinglePartialUser.GetVlaSinglePartialUserByUserId(userId)

            Return ConvertToStructure(userObject)

        Catch ex As Exception
            WriteLogEntry(ex)
            Return Nothing
        End Try
    End Function

    <WebMethod()> _
    Public Function GetRolesByLogin(ByVal login As String) As VlaRole()
        Try
            Dim roleCollection As VlaRoleCollection

            roleCollection = VlaRoleCollection.GetVlaRoleCollectionForLogin(login)

            Return ConvertToStructure(roleCollection)

        Catch ex As Exception
            WriteLogEntry(ex)
            Return Nothing
        End Try
    End Function

    <WebMethod()> _
    Public Function GetRolesBySystem(ByVal systemId As String) As VlaRole()
        Try
            Dim roleCollection As VlaRoleCollection
            Dim systemGuid As Guid = New Guid(systemId)

            roleCollection = VlaRoleCollection.GetVlaRoleCollectionForSystem(systemGuid)

            Return ConvertToStructure(roleCollection)

        Catch ex As Exception
            WriteLogEntry(ex)
            Return Nothing
        End Try
    End Function

    <WebMethod()> _
    Public Function CheckRoleExists(ByVal roleName As String) As Boolean
        Try
            Dim roleCollection As VlaRoleCollection

            roleCollection = VlaRoleCollection.GetVlaRoleCollection()

            For Each currentRole As VlaSingleRole In roleCollection
                If currentRole.Name = roleName Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception
            WriteLogEntry(ex)
            Return False
        End Try
    End Function

    <WebMethod()> _
        Public Function GetOnePointFiveUser(ByVal tokenId As Guid, ByVal passcodeChar1 As Char, ByVal passcodeChar2 As Char) As VlaUser

        Try
            Dim userObject As VlaSingleUser

            userObject = VlaSingleUser.GetOnePointFiveVlaSingleUser(tokenId, passcodeChar1, passcodeChar2)

            Return ConvertToStructure(userObject)
        Catch ex As Exception
            If TypeOf (ex.InnerException.InnerException) Is UserManagementBusinessObjects.AuthenticationFailedException Then
                Return Nothing
            Else
                WriteLogEntry(ex)
                Return Nothing
            End If
        End Try
    End Function

    <WebMethod()> _
    Public Function GetOnePointFiveUserWithIp(ByVal tokenId As Guid, ByVal passcodeChar1 As Char, ByVal passcodeChar2 As Char, ByVal sourceIp As String) As VlaUser

        Try
            Dim userObject As VlaSingleUser

            userObject = VlaSingleUser.GetOnePointFiveVlaSingleUser(tokenId, passcodeChar1, passcodeChar2, sourceIp)

            Return ConvertToStructure(userObject)
        Catch ex As Exception
            If TypeOf (ex.InnerException.InnerException) Is UserManagementBusinessObjects.AuthenticationFailedException Then
                Return Nothing
            Else
                WriteLogEntry(ex)
                Return Nothing
            End If
        End Try
    End Function

    <WebMethod()> _
       Public Function GetUserByTokenId(ByVal tokenId As Guid) As VlaUser
        Try
            Dim userObject As VlaSingleUser

            userObject = VlaSingleUser.GetVlaSingleUserByTokenId(tokenId)

            Return ConvertToStructure(userObject)

        Catch ex As Exception
            WriteLogEntry(ex)
            Return Nothing
        End Try
    End Function

    <WebMethod()> _
    Public Function UpdateUser(ByVal user As VlaUser) As Boolean
        Try
            Dim userObject As VlaSingleUser

            userObject = ConvertFromStructure(user)

            userObject.Save()

            Return True

        Catch ex As Exception
            WriteLogEntry(ex)
            Return False
        End Try
    End Function

    <WebMethod()> _
    Public Function AuthoriseUser(ByVal tokenId As Guid, ByVal roleId As Guid) As Boolean
        Try
            If tokenId = Guid.Empty Then
                Return False
            End If

            Return VlaSingleUser.Authorise(tokenId, roleId)

        Catch ex As Exception
            WriteLogEntry(ex)
            Return False
        End Try
    End Function

    <WebMethod()> _
    Public Function LogOut(ByVal tokenId As Guid) As Boolean
        Try
            VlaSingleUser.Logout(tokenId)

            Return True
        Catch ex As Exception
            WriteLogEntry(ex)
            Return False
        End Try
    End Function

    <WebMethod()> _
    Public Function IsUserOnePointFiveAuthenticated(ByVal tokenId As Guid) As Boolean
        Try
            Return VlaSingleUser.IsUserOnePointFiveAuthenticated(tokenId)

        Catch ex As Exception
            WriteLogEntry(ex)
            Return False
        End Try
    End Function

    <WebMethod()> _
    Public Function ChangePassword(ByVal userId As Guid, ByVal oldPassword As String, ByVal newPassword As String) As Boolean
        Try
            Return VlaSingleUser.ChangePassword(userId, oldPassword, newPassword)
        Catch ex As Exception
            If TypeOf (ex.InnerException.InnerException) Is UserManagementBusinessObjects.AuthenticationFailedException Then
                Return False
            Else
                WriteLogEntry(ex)
                Return False
            End If
        End Try
    End Function

    '<WebMethod()> _
    '    Public Function ResetPassword(ByVal login As String) As Boolean
    '    Try
    '        Return VlaSingleUser.ResetPassword(login)
    '    Catch ex As Exception
    '        WriteLogEntry(ex)
    '        Return False
    '    End Try
    'End Function

    <WebMethod()> _
    Public Function ResetPassword(ByVal passwordResetKey As Guid) As Boolean
        Try
            Return VlaSingleUser.ResetPassword(passwordResetKey)
        Catch ex As Exception
            WriteLogEntry(ex)
            Return False
        End Try
    End Function

    <WebMethod()> _
    Public Function RequestPasswordReset(ByVal login As String) As Boolean
        Try
            Return VlaSingleUser.RequestPasswordReset(login)
        Catch ex As Exception
            WriteLogEntry(ex)
            Return False
        End Try
    End Function

    <WebMethod()> _
        Public Function ChangePasscode(ByVal userId As Guid, ByVal oldPasscode As String, ByVal newPasscode As String) As Boolean
        Try
            VlaSingleUser.ChangePasscode(userId, oldPasscode, newPasscode)

            Return True
        Catch ex As Exception
            If TypeOf (ex.InnerException.InnerException) Is UserManagementBusinessObjects.AuthenticationFailedException Then
                Return False
            Else
                WriteLogEntry(ex)
                Return False
            End If
        End Try
    End Function

    <WebMethod()> _
        Public Function ResetPasscode(ByVal login As String) As Boolean
        Try
            VlaSingleUser.ResetPasscode(login)

            Return True
        Catch ex As Exception
            WriteLogEntry(ex)
            Return False
        End Try
    End Function

    <WebMethod()> _
        Public Function GetMaxLoginAttempts() As Integer

        Try
            Return Settings.GetMaxLoginAttempts()

        Catch ex As Exception
            WriteLogEntry(ex)
            Return 0
        End Try

    End Function

    <WebMethod()> _
            Public Function TestDatabaseAccess() As Boolean
        Try
            Return TestDatabase.TestDatabaseAccess()
        Catch ex As Exception
            WriteLogEntry(ex)
            Return False
        End Try
    End Function

    <WebMethod()> _
        Public Function GetMessage() As String
        Try
            Dim messageObject As Message

            messageObject = Message.GetMessage()

            Return messageObject.Text
        Catch ex As Exception
            If TypeOf (ex.InnerException.InnerException) Is UserManagementBusinessObjects.AuthenticationFailedException Then
                Return Nothing
            Else
                WriteLogEntry(ex)
                Return Nothing
            End If
        End Try
    End Function

    Private Function ConvertToStructure(ByVal userCollection As VlaPartialUserCollection) As VlaPartialUser()
        Dim index As Integer = 0
        Dim returnUsers(userCollection.Count - 1) As VlaPartialUser

        For Each currentUser As VlaSinglePartialUser In userCollection
            returnUsers(index) = ConvertToStructure(currentUser)
            index = index + 1
        Next

        Return returnUsers
    End Function

    Private Function ConvertToStructure(ByVal userObject As VlaSinglePartialUser) As VlaPartialUser
        Dim returnUser As VlaPartialUser = New VlaPartialUser

        returnUser.Id = userObject.UserId
        returnUser.Login = userObject.Login
        returnUser.Email = userObject.Email
        returnUser.IsLockedOut = userObject.IsLockedOut

        Return returnUser
    End Function

    Private Function ConvertToStructure(ByVal userObject As VlaSingleUser) As VlaUser
        Dim returnUser As VlaUser = New VlaUser

        returnUser.Id = userObject.UserId
        returnUser.TokenId = userObject.TokenId
        returnUser.Login = userObject.Login
        returnUser.Email = userObject.Email
        returnUser.FirstName = userObject.FirstName
        returnUser.LastName = userObject.LastName
        returnUser.OrganisationName = userObject.OrganisationName
        returnUser.PhoneNumber = userObject.PhoneNumber
        returnUser.PasscodeIndex1 = userObject.PasscodeIndex1
        returnUser.PasscodeIndex2 = userObject.PasscodeIndex2
        returnUser.IsAllocatedOnePointFiveSystems = userObject.IsAllocatedOnePointFiveSystems
        returnUser.IsLoginFixed = userObject.IsLoginFixed
        returnUser.MustChangePassword = userObject.MustChangePassword
        returnUser.PreviousLoginDate = userObject.PreviousLoginDate
        returnUser.PasswordResetKey = userObject.PasswordResetKey
        returnUser.PasswordResetKeyDate = userObject.PasswordResetKeyDate

        Dim index As Integer = 0
        Dim returnSystems(userObject.VlaSystems.Count - 1) As VlaSystem

        For Each currentSystem As VlaSingleSystem In userObject.VlaSystems
            returnSystems(index) = ConvertToStructure(currentSystem)
            index = index + 1
        Next

        returnUser.Systems = returnSystems

        Return returnUser
    End Function

    Private Function ConvertToStructure(ByVal systemObject As VlaSingleSystem) As VlaSystem
        Dim returnSystem As VlaSystem = New VlaSystem

        returnSystem.Id = systemObject.SystemId
        returnSystem.Name = systemObject.Name
        returnSystem.Url = systemObject.Url
        returnSystem.Description = systemObject.Description
        returnSystem.RequiresOnePointFive = systemObject.RequiresOnePointFive
        returnSystem.Roles = ConvertToStructure(systemObject.VlaRoles)

        Return returnSystem
    End Function

    Private Function ConvertToStructure(ByVal rolesCollection As VlaRoleCollection) As VlaRole()
        Dim index As Integer = 0
        Dim returnRoles(rolesCollection.Count - 1) As VlaRole

        For Each currentRole As VlaSingleRole In rolesCollection
            returnRoles(index) = ConvertToStructure(currentRole)
            index = index + 1
        Next

        Return returnRoles
    End Function

    Private Function ConvertToStructure(ByVal roleObject As VlaSingleRole) As VlaRole
        Dim returnRole As VlaRole = New VlaRole

        returnRole.Id = roleObject.RoleId
        returnRole.Name = roleObject.Name

        Return returnRole
    End Function

    Private Function ConvertFromStructure(ByVal vlaUser As VlaUser) As VlaSingleUser
        Dim userObject As VlaSingleUser

        userObject = VlaSingleUser.GetVlaSingleUser(vlaUser.Id)
        If Not userObject.IsLoginFixed Then
            userObject.Login = vlaUser.Login
        End If
        userObject.Email = vlaUser.Email
        userObject.FirstName = vlaUser.FirstName
        userObject.LastName = vlaUser.LastName
        userObject.OrganisationName = vlaUser.OrganisationName
        userObject.PhoneNumber = vlaUser.PhoneNumber

        Return userObject
    End Function

    Private Sub WriteLogEntry(ByVal ex As Exception)

        'log the details of the exception and page state to the event log.
        'If the following line causes an exception, make sure the following registry permissions are set
        'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Eventlog          - needs READ permission for the ASP.NET account
        'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Eventlog\Security - needs R/W permission for the ASP.NET account
        EventLog.WriteEntry("User Management", "MESSAGE: " + ex.Message + Environment.NewLine + "SOURCE: " + ex.Source + Environment.NewLine + ex.StackTrace, EventLogEntryType.Error, 0)
        While Not ex.InnerException Is Nothing
            ex = ex.InnerException
            WriteLogEntry(ex)
        End While

    End Sub

End Class



